# Using the recorder

To enable the recorder, run the program using the `--record` flag
```
go run . --record
```
# Space consideration for the database

Player positions are constantly polled thought the game's lifespan.


